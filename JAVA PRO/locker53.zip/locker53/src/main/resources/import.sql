insert into users(username, password, role) values ('admin', 'admin', 'ROLE_ADMIN');

insert into users(username, password, role) values ('user', 'user', 'ROLE_USER');