package module5.lesson4_unit_testing.task2;

public interface OuterService {

    Integer getNumber();
}