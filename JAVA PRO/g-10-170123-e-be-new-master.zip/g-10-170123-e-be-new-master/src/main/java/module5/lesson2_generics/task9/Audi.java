package module5.lesson2_generics.task9;

public class Audi extends Car {

    @Override
    public String toString() {
        return "Audi";
    }
}
