package module5.lesson2_generics.task9;

public class Airplane extends Vehicle {

    @Override
    public String toString() {
        return "Airplane";
    }
}
