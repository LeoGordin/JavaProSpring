package module5.lesson2_generics.task10;

public class Apple extends Fruit {

    public Apple() {
        super(1);
    }
}