package module5.lesson2_generics.task9;

public class Honda extends Car {

    @Override
    public String toString() {
        return "Honda";
    }
}
