package module5.lesson2_generics.task10;

public class Orange extends Fruit {

    public Orange() {
        super(1.5f);
    }
}