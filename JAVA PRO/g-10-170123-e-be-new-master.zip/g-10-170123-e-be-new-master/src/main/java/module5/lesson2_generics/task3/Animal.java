package module5.lesson2_generics.task3;

public abstract class Animal {
}
