package module5.lesson3_exceptions.example;

public class OuterService {

    public Integer getNumber() {
        return null;
    }
}
