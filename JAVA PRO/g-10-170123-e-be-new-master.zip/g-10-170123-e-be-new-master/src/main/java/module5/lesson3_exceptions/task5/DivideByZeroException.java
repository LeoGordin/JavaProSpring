package module5.lesson3_exceptions.task5;

public class DivideByZeroException extends Exception {
}
