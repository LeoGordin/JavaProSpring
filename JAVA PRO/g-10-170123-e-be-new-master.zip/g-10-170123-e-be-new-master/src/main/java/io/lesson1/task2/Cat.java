package io.lesson1.task2;

public class Cat {
}
