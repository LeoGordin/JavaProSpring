package io.lesson1.task1;

public class Main {

    public static void main(String[] args) {

        System.out.print("One! ");
        System.out.print("Two! ");
        System.out.print("Three!");

        System.out.println();

        System.out.println("One! ");
        System.out.println("Two! ");
        System.out.println("Three!");
    }
}
