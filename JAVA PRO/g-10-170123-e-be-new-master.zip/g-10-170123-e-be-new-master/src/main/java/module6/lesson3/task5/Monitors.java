package module6.lesson3.task5;

public interface Monitors {

    String MONITOR = "";
}
