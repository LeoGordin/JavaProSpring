package module6.lesson2.task2;

public class Main {

    public static void main(String[] args) {

        Service.test(() -> System.out.println("X"));
    }
}
